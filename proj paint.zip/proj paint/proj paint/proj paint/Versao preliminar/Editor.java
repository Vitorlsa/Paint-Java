public class Editor
{
    public static void main (String args[])
    {
        new Janela ();
    }
}
