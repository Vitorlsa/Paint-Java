import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.imageio.*;
import java.io.*;
import java.util.*;
//import ZoeloeSoft.projects.JFontChooser.JFontChooser;

public class Janela extends JFrame {
	protected static final long serialVersionUID = 1L;

	protected JButton btnPonto = new JButton("Ponto"), btnLinha = new JButton("Linha"),
			btnCirculo = new JButton("Circulo"), btnElipse = new JButton("Elipse"), btnCores = new JButton("Cores"),
			btnAbrir = new JButton("Abrir"), btnSalvar = new JButton("Salvar"), btnApagar = new JButton("Apagar"),
			btnSair = new JButton("Sair");

	protected MeuJPanel pnlDesenho = new MeuJPanel();

	protected JLabel statusBar1 = new JLabel("Mensagem:"), statusBar2 = new JLabel("Coordenada:");

	protected boolean esperaPonto, esperaInicioReta, esperaFimReta, esperaCores, esperaAbrir, esperaSalvar,
			esperaCentroCirculo, esperaCentroElipse, eseperaRaioCirculo, esperaRaioElipse;

	protected Color corAtual = Color.BLACK;
	protected Ponto p1, centro;

	protected Vector<Figura> figuras = new Vector<Figura>();

	/* cor */
	protected JButton changeColorJButton;
	protected Color color = Color.LIGHT_GRAY;
	protected JPanel colorJPanel;

	public Janela() {
		super("Editor Gr�fico");

		try {
			Image btnPontoImg = ImageIO.read(getClass().getResource("ponto.jpg"));
			btnPonto.setIcon(new ImageIcon(btnPontoImg));
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Arquivo ponto.jpg n�o foi encontrado", "Arquivo de imagem ausente",
					JOptionPane.WARNING_MESSAGE);
		}

		try {
			Image btnLinhaImg = ImageIO.read(getClass().getResource("linha.jpg"));
			btnLinha.setIcon(new ImageIcon(btnLinhaImg));
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Arquivo linha.jpg n�o foi encontrado", "Arquivo de imagem ausente",
					JOptionPane.WARNING_MESSAGE);
		}

		try {
			Image btnCirculoImg = ImageIO.read(getClass().getResource("circulo.jpg"));
			btnCirculo.setIcon(new ImageIcon(btnCirculoImg));
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Arquivo circulo.jpg n�o foi encontrado", "Arquivo de imagem ausente",
					JOptionPane.WARNING_MESSAGE);
		}

		try {
			Image btnElipseImg = ImageIO.read(getClass().getResource("elipse.jpg"));
			btnElipse.setIcon(new ImageIcon(btnElipseImg));
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Arquivo elipse.jpg n�o foi encontrado", "Arquivo de imagem ausente",
					JOptionPane.WARNING_MESSAGE);
		}

		try {
			Image btnCoresImg = ImageIO.read(getClass().getResource("cores.jpg"));
			btnCores.setIcon(new ImageIcon(btnCoresImg));
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Arquivo cores.jpg n�o foi encontrado", "Arquivo de imagem ausente",
					JOptionPane.WARNING_MESSAGE);
		}

		try {
			Image btnAbrirImg = ImageIO.read(getClass().getResource("abrir.jpg"));
			btnAbrir.setIcon(new ImageIcon(btnAbrirImg));
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Arquivo abrir.jpg n�o foi encontrado", "Arquivo de imagem ausente",
					JOptionPane.WARNING_MESSAGE);
		}

		try {
			Image btnSalvarImg = ImageIO.read(getClass().getResource("salvar.jpg"));
			btnSalvar.setIcon(new ImageIcon(btnSalvarImg));
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Arquivo salvar.jpg n�o foi encontrado", "Arquivo de imagem ausente",
					JOptionPane.WARNING_MESSAGE);
		}

		try {
			Image btnApagarImg = ImageIO.read(getClass().getResource("apagar.jpg"));
			btnApagar.setIcon(new ImageIcon(btnApagarImg));
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Arquivo apagar.jpg n�o foi encontrado", "Arquivo de imagem ausente",
					JOptionPane.WARNING_MESSAGE);
		}

		try {
			Image btnSairImg = ImageIO.read(getClass().getResource("sair.jpg"));
			btnSair.setIcon(new ImageIcon(btnSairImg));
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Arquivo sair.jpg n�o foi encontrado", "Arquivo de imagem ausente",
					JOptionPane.WARNING_MESSAGE);
		}

		btnPonto.addActionListener(new DesenhoDePonto());
		btnLinha.addActionListener(new DesenhoDeReta());
		btnCirculo.addActionListener(new DesenhoDeCirculo());
		btnElipse.addActionListener(new DesenhoDeElipse());
		btnCores.addActionListener(new TrocaDeCores());
		btnAbrir.addActionListener(new AbrirDesenho());
		btnSalvar.addActionListener(new SalvardDesenho());

		JPanel pnlBotoes = new JPanel();
		FlowLayout flwBotoes = new FlowLayout();
		pnlBotoes.setLayout(flwBotoes);

		pnlBotoes.add(btnAbrir);
		pnlBotoes.add(btnSalvar);
		pnlBotoes.add(btnPonto);
		pnlBotoes.add(btnLinha);
		pnlBotoes.add(btnCirculo);
		pnlBotoes.add(btnElipse);
		pnlBotoes.add(btnCores);
		pnlBotoes.add(btnApagar);
		pnlBotoes.add(btnSair);

		JPanel pnlStatus = new JPanel();
		GridLayout grdStatus = new GridLayout(1, 2);
		pnlStatus.setLayout(grdStatus);

		pnlStatus.add(statusBar1);
		pnlStatus.add(statusBar2);

		Container cntForm = this.getContentPane();
		cntForm.setLayout(new BorderLayout());
		cntForm.add(pnlBotoes, BorderLayout.NORTH);
		cntForm.add(pnlDesenho, BorderLayout.CENTER);
		cntForm.add(pnlStatus, BorderLayout.SOUTH);

		this.addWindowListener(new FechamentoDeJanela());

		this.setSize(700, 500);
		this.setVisible(true);
	}

	protected class MeuJPanel extends JPanel implements MouseListener, MouseMotionListener {
		public MeuJPanel() {
			super();

			this.addMouseListener(this);
			this.addMouseMotionListener(this);
		}

		public void paint(Graphics g) {
			for (int i = 0; i < figuras.size(); i++)
				figuras.get(i).torneSeVisivel(g);
		}

		public void mousePressed(MouseEvent e) {
			if (esperaPonto) {
				figuras.add(new Ponto(e.getX(), e.getY(), corAtual));
				figuras.get(figuras.size() - 1).torneSeVisivel(pnlDesenho.getGraphics());
				esperaPonto = false;
			} else if (esperaInicioReta) {
				p1 = new Ponto(e.getX(), e.getY(), corAtual);
				esperaInicioReta = false;
				esperaFimReta = true;
				statusBar1.setText("Mensagem: clique o ponto final da reta");
			} else if (esperaFimReta) {
				esperaInicioReta = false;
				esperaFimReta = false;
				figuras.add(new Linha(p1.getX(), p1.getY(), e.getX(), e.getY(), corAtual));
				figuras.get(figuras.size() - 1).torneSeVisivel(pnlDesenho.getGraphics());
				statusBar1.setText("Mensagem:");
			} else if (esperaCentroCirculo) {
				esperaCentroCirculo = false;
				eseperaRaioCirculo = true;
				p1 = new Ponto(e.getX(), e.getY(), corAtual);
				statusBar1.setText("Mensagem: clique o centro do circulo");
			} else if (eseperaRaioCirculo) {
				esperaCentroCirculo = false;
				eseperaRaioCirculo = false;

				/*int raio = 0;
				if (e.getX() > p1.getX())
					raio = Math.abs(e.getX() - p1.getX());
				else if (e.getY() > p1.getY())
					raio = Math.abs(e.getY() - p1.getY());
				else if (e.getY() <= p1.getY())
					raio = Math.abs(p1.getY() - e.getY());
				else if (e.getX() <= p1.getX())
					raio = Math.abs(e.getX() - p1.getX());
*/
				
				double raio = Math.sqrt(Math.pow(e.getX() - p1.getX(), 2) + Math.pow(e.getY() - p1.getY(), 2)); 
				figuras.add(new Circulo(p1.getX(), p1.getY(), (int)raio, corAtual));
				figuras.get(figuras.size() - 1).torneSeVisivel(pnlDesenho.getGraphics());
				statusBar1.setText("Mensagem: ");
			} else if (esperaCentroElipse) {
				esperaCentroElipse = false;
				esperaRaioElipse = true;
				p1 = new Ponto(e.getX(), e.getY(), corAtual);
			} else if (esperaRaioElipse) {
				esperaCentroElipse = false;
				esperaRaioElipse = false;

				int r1 = Math.abs(e.getX() - p1.getX()) / 2;
				int r2 = Math.abs(e.getY() - p1.getY()) /2;
				centro = new Ponto((e.getX() + p1.getX()) / 2, (e.getY() + p1.getY()) / 2);
				figuras.add(new Elipse(centro.getX(), centro.getY(), r1, r2, corAtual));
				figuras.get(figuras.size() - 1).torneSeVisivel(pnlDesenho.getGraphics());
			}

			else if (esperaSalvar) {
				/*
				 * try{
				 * 
				 * PrintWriter gravador = new PrintWriter ( new FileWriter ( "arquivo.txt"));
				 * 
				 * 
				 * for(int i = 0; i<= figuras.size(); i++){ figuras.toString(); }
				 * 
				 * 
				 * esperaSalvar = false;
				 * 
				 * gravador.close(); }catch(Exception erro){
				 * statusBar1.setText("Mensagem: Erro ao salvar"); }
				 */

			} else if (esperaAbrir) {
				/*
				 * try { BufferedReader leitor = new BufferedReader(new
				 * FileReader("arquivo.txt"));
				 * 
				 * while (leitor.ready()) System.out.println(leitor.readLine());
				 * 
				 * leitor.close(); } catch (Exception erro) {
				 * statusBar1.setText("Mensagem: Problema com o arquivo"); }
				 */
			}
		}

		public void mouseReleased(MouseEvent e) {
		}

		public void mouseClicked(MouseEvent e) {
		}

		public void mouseEntered(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
		}

		public void mouseDragged(MouseEvent e) {
		}

		public void mouseMoved(MouseEvent e) {
			statusBar2.setText("Coordenada: " + e.getX() + "," + e.getY());
		}
	}

	protected class ShowColors2JFrame extends JFrame {

		public ShowColors2JFrame() {
			super("Usando o JColorChooser");

			colorJPanel = new JPanel();
			colorJPanel.setBackground(color);

			changeColorJButton = new JButton("Escolher a cor");
			changeColorJButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent event) {
					corAtual = JColorChooser.showDialog(ShowColors2JFrame.this, "Escolher a color", color);

					if (color == null)
						color = Color.LIGHT_GRAY;
					colorJPanel.setBackground(color);
				}
			});

			add(colorJPanel, BorderLayout.CENTER);
			add(changeColorJButton, BorderLayout.SOUTH);

			setSize(400, 130);
			setVisible(true);
		}
	}

	protected class DesenhoDePonto implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			esperaPonto = true;
			esperaInicioReta = false;
			esperaFimReta = false;
			esperaCores = false;
			esperaAbrir = false;
			esperaSalvar = false;
			esperaCentroCirculo = false;
			esperaCentroElipse = false;
			eseperaRaioCirculo = false;
			esperaRaioElipse = false;

			statusBar1.setText("Mensagem: clique o local do ponto desejado");
		}
	}

	protected class DesenhoDeReta implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			esperaPonto = false;
			esperaInicioReta = true;
			esperaFimReta = false;
			esperaCores = false;
			esperaAbrir = false;
			esperaSalvar = false;
			esperaCentroCirculo = false;
			esperaCentroElipse = false;
			eseperaRaioCirculo = false;
			esperaRaioElipse = false;

			statusBar1.setText("Mensagem: clique o ponto inicial da reta");
		}
	}

	protected class DesenhoDeCirculo implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			// fazer essa porra
			esperaPonto = false;
			esperaInicioReta = false;
			esperaFimReta = false;
			esperaCores = false;
			esperaAbrir = false;
			esperaSalvar = false;
			esperaCentroCirculo = true;
			esperaCentroElipse = false;
			eseperaRaioCirculo = false;
			esperaRaioElipse = false;

			statusBar1.setText("Mensagem: clique o ponto inicial do circulo");
		}
	}

	protected class DesenhoDeElipse implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			// fazer essa porra

			esperaPonto = false;
			esperaInicioReta = false;
			esperaFimReta = false;
			esperaCores = false;
			esperaAbrir = false;
			esperaSalvar = false;
			esperaCentroCirculo = false;
			esperaCentroElipse = true;
			eseperaRaioCirculo = false;
			esperaRaioElipse = false;

			statusBar1.setText("Mensagem: clique o ponto inicial da elipse");

		}
	}

	protected class TrocaDeCores implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			statusBar1.setText("Mensagem: trocar cor");
			ShowColors2JFrame application = new ShowColors2JFrame();

		}
	}

	protected class SalvardDesenho implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			try {
				JFileChooser file = new JFileChooser();
				file.setFileSelectionMode(JFileChooser.FILES_ONLY);
				int i = file.showSaveDialog(null);
				File arquivo = file.getSelectedFile();

				boolean txt = new File(file.getSelectedFile().toString()).exists();
				if (txt){
					JFrame frame = new JFrame("Aten��o!");
					JOptionPane.showMessageDialog(frame, "O arquivo ja existe e ser� substitu�do");
				}
				PrintWriter gravador = new PrintWriter(new FileWriter(arquivo.getPath()));

				Enumeration enu = figuras.elements();

				while (enu.hasMoreElements()) {
					gravador.println(enu.nextElement().toString());
				}
				gravador.close();
				statusBar1.setText("Mensagem: SALVOU SAPORRA");
			} catch (Exception erro) {
				statusBar1.setText("Mensagem: Erro ao salvar");
			}

			statusBar1.setText("Mensagem: clique para salvar");
		}
	}

	protected class AbrirDesenho implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			System.out.println("Abrir desenho");
			try {

				JFileChooser file = new JFileChooser();
				file.setFileFilter(new FileNameExtensionFilter("TEXT FILES", "txt", "text"));
				file.setFileSelectionMode(JFileChooser.FILES_ONLY);
				int i = file.showOpenDialog(null);
				File arquivo = file.getSelectedFile();

				BufferedReader leitor = new BufferedReader(new FileReader(arquivo.getPath()));

				while (leitor.ready()) {

					String fig = leitor.readLine();
					if (fig.charAt(0) == 'e') {
						figuras.add(new Elipse(fig));
						figuras.get(figuras.size() - 1).torneSeVisivel(pnlDesenho.getGraphics());
					} else if (fig.charAt(0) == 'c') {
						figuras.add(new Circulo(fig));
						figuras.get(figuras.size() - 1).torneSeVisivel(pnlDesenho.getGraphics());
					} else if (fig.charAt(0) == 'r') {
						figuras.add(new Linha(fig));
						figuras.get(figuras.size() - 1).torneSeVisivel(pnlDesenho.getGraphics());
					} else if (fig.charAt(0) == 'p') {
						figuras.add(new Ponto(fig));
						figuras.get(figuras.size() - 1).torneSeVisivel(pnlDesenho.getGraphics());
					}
				}
				leitor.close();

			} catch (Exception erro) {
			}

			statusBar1.setText("Mensagem: abra o desenho");

		}
	}

	protected class FechamentoDeJanela extends WindowAdapter {
		public void windowClosing(WindowEvent e) {
			System.exit(0);
		}
	}
}
